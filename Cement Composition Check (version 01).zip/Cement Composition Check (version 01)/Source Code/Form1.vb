﻿Imports System.ComponentModel

Public Class Form1
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub bttn_Check_Click(sender As Object, e As EventArgs) Handles bttn_Check.Click

        outputTextbox2.Clear()

        Try



            Dim C, S, A, F, SO3, MgO, LOI, IR As Double

            C = Convert.ToDouble(txt_CaO.Text)
            S = Convert.ToDouble(txt_SiO2.Text)
            A = Convert.ToDouble(txt_Al2O3.Text)
            F = Convert.ToDouble(txt_Fe2O3.Text)
            SO3 = Convert.ToDouble(txt_SO3.Text)
            MgO = Convert.ToDouble(txt_MgO.Text)
            LOI = Convert.ToDouble(txt_LOI.Text)
            IR = Convert.ToDouble(txt_IR.Text)

            Print("INPUTS")
            Print("-------")
            Print("CaO =", C, "%")
            Print("SiO2 =", S, "%")
            Print("Al2O3 =", A, "%")
            Print("Fe2O3 =", F, "%")
            Print("SO3 =", SO3, "%")
            Print("MgO =", MgO, "%")
            Print("LOI (Loss on Ignition) =", LOI, "%")
            Print("IR (Insoluble Residue =", IR, "%")
            Print("")


            Dim sum As Double = C + S + A + F + SO3 + MgO + LOI + IR
            Dim sumCheck As Boolean = Math.Abs(100 - sum) <= 2.0

            If (Not sumCheck) Then

                Print("ERROR")
                Print("SUM OF PERCENTAGES OF CONSTITUENTS SHOULD BE 100% ± 2%")

            Else

                Dim C3S, C2S, C3A, C4AF, C4AF_2C3A As Double

                C3S = 4.07 * C - 7.6 * S - 6.72 * A - 1.43 * F - 2.85 * SO3
                C2S = 2.87 * S - 0.75 * C3S
                C3A = 2.65 * A - 1.69 * F
                C4AF = 3.04 * F
                C4AF_2C3A = C4AF + 2 * C3A

                Print("BOGUE COMPOSITION")
                Print("------------------")
                Print("C3S =", C3S, "%")
                Print("C2S =", C2S, "%")
                Print("C3A =", C3A, "%")
                Print("C4AF =", C4AF, "%")
                Print("C4AF + 2*C3A =", C4AF_2C3A, "%")
                Print("")



                If (C3S < 0 Or C2S < 0 Or C3A < 0 Or C4AF < 0) Then

                    Print("ERROR")
                    Print("NEGATIVE VALUE COMPUTED FOR CEMENT COMPOUNDS. CHECK INPUTS.")

                Else

                    Print("ASTM C-150 CEMENT TYPE COMPLIANCE CHECKS")
                    Print("----------------------------------------")
                    Print("")

                    Print("Type-I:")
                    Print("-------")
                    Dim type1 As Boolean = Check("MgO <= 6%", MgO <= 6)
                    If (C3A <= 8) Then
                        type1 = type1 And Check("SO3 <= 3%", SO3 <= 3)
                    Else
                        type1 = type1 And Check("SO3 <= 3.5%", SO3 <= 3.5)
                    End If

                    type1 = type1 And Check("LOI <= 3%", LOI <= 3)
                    type1 = type1 And Check("IR <= 0.75%", IR <= 0.75)

                    Print("")
                    Print("    Remarks: The cement composition is " & If(type1, "COMPLIANT", "NON-COMPLIANT") & " with ASTM C-150 Type-I specification.")
                    'Print("    Type I compliance:", If(type1, "Compliant", "Non Compliant"))
                    Print("")

                    Print("Type-II:")
                    Print("--------")
                    Dim type2 As Boolean = Check("MgO <= 6%", MgO <= 6)
                    type2 = type2 And Check("C3A <= 8%", C3A <= 8)
                    type2 = type2 And (Check("SO3 <= 3%", SO3 <= 3))
                    type2 = type2 And Check("SiO2 >= 20%", S >= 20)
                    type2 = type2 And Check("Al2O3 <= 6%", A <= 6)
                    type2 = type2 And (Check("LOI <= 3%", LOI <= 3))
                    type2 = type2 And (Check("IR <= 0.75%", IR <= 0.75))
                    Print("")
                    Print("    Remarks: The cement composition is " & If(type2, "COMPLIANT", "NON-COMPLIANT") & " with ASTM C-150 Type-II specification.")
                    'Print("    Type II compliance:", If(type2, "Compliant", "Non Compliant"))
                    Print("")


                    Print("Type-III:")
                    Print("---------")
                    Dim type3 As Boolean = Check("MgO <= 6%", MgO <= 6)
                    If C3A <= 8 Then
                        type3 = type3 And Check("SO3 <= 3.5%", SO3 <= 3.5)
                    Else
                        type3 = type3 And (Check("SO3 <= 4.5%", SO3 <= 4.5))
                    End If

                    type3 = type3 And Check("LOI <= 3%", LOI <= 3)
                    type3 = type3 And Check("IR <= 0.75%", IR <= 0.75)
                    Print("")
                    Print("    Remarks: The cement composition is " & If(type3, "COMPLIANT", "NON-COMPLIANT") & " with ASTM C-150 Type-III specification.")
                    'Print("    Type III compliance:", If(type3, "Compliant", "Non Compliant"))
                    Print("")


                    Print("Type-IV:")
                    Print("--------")
                    Dim type4 As Boolean = (Check("F <= 6.5%", F <= 6.5))
                    type4 = type4 And Check("MgO <= 6%", MgO <= 6)
                    type4 = type4 And Check("C3A <= 7%", C3A <= 7)
                    type4 = type4 And Check("SO3 <= 2.3%", SO3 <= 2.3)
                    type4 = type4 And Check("C3S <= 35%", C3S <= 35)
                    type4 = type4 And Check("C2S <= 40%", C2S <= 40)
                    type4 = type4 And Check("LOI <= 2.5%", LOI <= 2.5)
                    type4 = type4 And Check("IR <= 0.75%", IR <= 0.75)
                    Print("")
                    Print("    Remarks: The cement composition is " & If(type4, "COMPLIANT", "NON-COMPLIANT") & " with ASTM C-150 Type-IV specification.")
                    'Print("    Type IV compliance:", If(type4, "Compliant", "Non Compliant"))
                    Print("")


                    Print("Type-V:")
                    Print("-------")
                    Dim type5 As Boolean = Check("MgO <= 6%", MgO <= 6)
                    type5 = type5 And Check("SO3 <= 2.3%", SO3 <= 2.3)
                    type5 = type5 And Check("C3A <= 5%", C3A <= 5)
                    type5 = type5 And Check("C4AF + 2C3A <= 25%", C4AF_2C3A <= 25)
                    type5 = type5 And Check("LOI <= 3%", LOI <= 3)
                    type5 = type5 And Check("IR <= 0.75%", IR <= 0.75)
                    Print("")
                    Print("    Remarks: The cement composition is " & If(type5, "COMPLIANT", "NON-COMPLIANT") & " with ASTM C-150 Type-V specification.")
                    'Print("    Type V compliance:", If(type5, "Compliant", "Non Compliant"))
                    Print("")

                    Print("")

                    'nespak checks
                    Print("OTHER CHECKS")
                    Print("-------------")


                    Print("")
                    Print("C3A limit, from 5 to 8 percent:", If((C3A >= 5) And (C3A <= 8), "COMPLIANT", "NON-COMPLIANT"))
                    Print("")
                    Print("AL2O3 limit, 6 percent maximum:", If((A <= 6), "COMPLIANT", "NON-COMPLIANT"))
                    Print("")
                    Print("C4AF + 2*C3A limit, 25 percent maximum:", If((C4AF_2C3A <= 25), "COMPLIANT", "NON-COMPLIANT"))
                    Print("")

                End If

            End If

        Catch e1 As Exception

            Print("ERROR")
            Print(e1.Message)

        End Try


    End Sub

    Private Sub Print(p1 As String)
        outputTextbox2.AppendText(p1)
        outputTextbox2.AppendText(vbCrLf)
    End Sub

    Private Sub Print(p1 As String, p2 As String)
        outputTextbox2.AppendText(p1)
        outputTextbox2.AppendText(" ")
        outputTextbox2.AppendText(p2)
        outputTextbox2.AppendText(vbCrLf)
    End Sub

    Private Sub Print(p1 As String, p2 As Double)
        outputTextbox2.AppendText(p1)
        outputTextbox2.AppendText(" ")
        outputTextbox2.AppendText(p2.ToString("0.000"))
        outputTextbox2.AppendText(vbCrLf)
    End Sub

    Private Sub Print(p1 As String, p2 As Double, unit As String)
        outputTextbox2.AppendText(p1)
        outputTextbox2.AppendText(" ")
        outputTextbox2.AppendText(p2.ToString("0.000"))
        outputTextbox2.AppendText(" ")
        outputTextbox2.AppendText(unit)
        outputTextbox2.AppendText(vbCrLf)
    End Sub

    Private Function Check(checkString As String, limitCheck As Boolean) As Boolean
        outputTextbox2.AppendText("    " & checkString & " ... " & If(limitCheck, "Yes", "No") & vbCrLf)

        Return limitCheck
    End Function

    Private Sub Form1_Closing(sender As Object, e As CancelEventArgs) Handles MyBase.Closing
        FormSerialisation.FormSerialisor.Serialise(Me, Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) & "\com-smushamsi-cementcompositioncheck-data.xml")

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FormSerialisation.FormSerialisor.Deserialise(Me, Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) & "\com-smushamsi-cementcompositioncheck-data.xml")

    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim str =
        "ASTM C-150 Cement Composition Check" &
        vbCrLf & vbCrLf &
        "Version: 01" &
        vbCrLf & vbCrLf &
        "Source code is available at https://github.com/usmanshamsi/cement_composition_check"

        MsgBox(str, vbOKOnly, "About this program...")
    End Sub
End Class
