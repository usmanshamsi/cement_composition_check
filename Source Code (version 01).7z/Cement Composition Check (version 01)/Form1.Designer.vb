﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        Label7 = New Label()
        Label8 = New Label()
        txt_CaO = New TextBox()
        txt_SO3 = New TextBox()
        txt_SiO2 = New TextBox()
        txt_Al2O3 = New TextBox()
        txt_Fe2O3 = New TextBox()
        txt_MgO = New TextBox()
        txt_LOI = New TextBox()
        txt_IR = New TextBox()
        bttn_Check = New Button()
        Label10 = New Label()
        Label11 = New Label()
        Label12 = New Label()
        Label13 = New Label()
        Label14 = New Label()
        Label15 = New Label()
        Label16 = New Label()
        Label17 = New Label()
        outputTextbox2 = New RichTextBox()
        Button1 = New Button()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(12, 15)
        Label1.Name = "Label1"
        Label1.Size = New Size(30, 15)
        Label1.TabIndex = 0
        Label1.Text = "CaO"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(12, 46)
        Label2.Name = "Label2"
        Label2.Size = New Size(31, 15)
        Label2.TabIndex = 1
        Label2.Text = "SiO2"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(12, 77)
        Label3.Name = "Label3"
        Label3.Size = New Size(39, 15)
        Label3.TabIndex = 2
        Label3.Text = "Al2O3"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(12, 108)
        Label4.Name = "Label4"
        Label4.Size = New Size(40, 15)
        Label4.TabIndex = 3
        Label4.Text = "Fe2O3"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(12, 139)
        Label5.Name = "Label5"
        Label5.Size = New Size(28, 15)
        Label5.TabIndex = 4
        Label5.Text = "SO3"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(12, 170)
        Label6.Name = "Label6"
        Label6.Size = New Size(34, 15)
        Label6.TabIndex = 5
        Label6.Text = "MgO"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(12, 201)
        Label7.Name = "Label7"
        Label7.Size = New Size(120, 15)
        Label7.TabIndex = 6
        Label7.Text = "Loss on Ignition (LOI)"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Location = New Point(12, 232)
        Label8.Name = "Label8"
        Label8.Size = New Size(120, 15)
        Label8.TabIndex = 7
        Label8.Text = "Insoluble Residue (IR)"
        ' 
        ' txt_CaO
        ' 
        txt_CaO.Location = New Point(156, 12)
        txt_CaO.Name = "txt_CaO"
        txt_CaO.Size = New Size(100, 23)
        txt_CaO.TabIndex = 0
        txt_CaO.TextAlign = HorizontalAlignment.Right
        ' 
        ' txt_SO3
        ' 
        txt_SO3.Location = New Point(156, 136)
        txt_SO3.Name = "txt_SO3"
        txt_SO3.Size = New Size(100, 23)
        txt_SO3.TabIndex = 4
        txt_SO3.TextAlign = HorizontalAlignment.Right
        ' 
        ' txt_SiO2
        ' 
        txt_SiO2.Location = New Point(156, 43)
        txt_SiO2.Name = "txt_SiO2"
        txt_SiO2.Size = New Size(100, 23)
        txt_SiO2.TabIndex = 1
        txt_SiO2.TextAlign = HorizontalAlignment.Right
        ' 
        ' txt_Al2O3
        ' 
        txt_Al2O3.Location = New Point(156, 74)
        txt_Al2O3.Name = "txt_Al2O3"
        txt_Al2O3.Size = New Size(100, 23)
        txt_Al2O3.TabIndex = 2
        txt_Al2O3.TextAlign = HorizontalAlignment.Right
        ' 
        ' txt_Fe2O3
        ' 
        txt_Fe2O3.Location = New Point(156, 105)
        txt_Fe2O3.Name = "txt_Fe2O3"
        txt_Fe2O3.Size = New Size(100, 23)
        txt_Fe2O3.TabIndex = 3
        txt_Fe2O3.TextAlign = HorizontalAlignment.Right
        ' 
        ' txt_MgO
        ' 
        txt_MgO.Location = New Point(156, 167)
        txt_MgO.Name = "txt_MgO"
        txt_MgO.Size = New Size(100, 23)
        txt_MgO.TabIndex = 5
        txt_MgO.TextAlign = HorizontalAlignment.Right
        ' 
        ' txt_LOI
        ' 
        txt_LOI.Location = New Point(156, 198)
        txt_LOI.Name = "txt_LOI"
        txt_LOI.Size = New Size(100, 23)
        txt_LOI.TabIndex = 6
        txt_LOI.TextAlign = HorizontalAlignment.Right
        ' 
        ' txt_IR
        ' 
        txt_IR.Location = New Point(156, 229)
        txt_IR.Name = "txt_IR"
        txt_IR.Size = New Size(100, 23)
        txt_IR.TabIndex = 7
        txt_IR.TextAlign = HorizontalAlignment.Right
        ' 
        ' bttn_Check
        ' 
        bttn_Check.Location = New Point(156, 269)
        bttn_Check.Name = "bttn_Check"
        bttn_Check.Size = New Size(123, 29)
        bttn_Check.TabIndex = 8
        bttn_Check.Text = "Check Compliance"
        bttn_Check.UseVisualStyleBackColor = True
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Location = New Point(262, 17)
        Label10.Name = "Label10"
        Label10.Size = New Size(17, 15)
        Label10.TabIndex = 19
        Label10.Text = "%"
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Location = New Point(262, 141)
        Label11.Name = "Label11"
        Label11.Size = New Size(17, 15)
        Label11.TabIndex = 20
        Label11.Text = "%"
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Location = New Point(262, 48)
        Label12.Name = "Label12"
        Label12.Size = New Size(17, 15)
        Label12.TabIndex = 21
        Label12.Text = "%"
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Location = New Point(262, 172)
        Label13.Name = "Label13"
        Label13.Size = New Size(17, 15)
        Label13.TabIndex = 22
        Label13.Text = "%"
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.Location = New Point(262, 79)
        Label14.Name = "Label14"
        Label14.Size = New Size(17, 15)
        Label14.TabIndex = 23
        Label14.Text = "%"
        ' 
        ' Label15
        ' 
        Label15.AutoSize = True
        Label15.Location = New Point(262, 203)
        Label15.Name = "Label15"
        Label15.Size = New Size(17, 15)
        Label15.TabIndex = 24
        Label15.Text = "%"
        ' 
        ' Label16
        ' 
        Label16.AutoSize = True
        Label16.Location = New Point(262, 234)
        Label16.Name = "Label16"
        Label16.Size = New Size(17, 15)
        Label16.TabIndex = 25
        Label16.Text = "%"
        ' 
        ' Label17
        ' 
        Label17.AutoSize = True
        Label17.Location = New Point(262, 110)
        Label17.Name = "Label17"
        Label17.Size = New Size(17, 15)
        Label17.TabIndex = 26
        Label17.Text = "%"
        ' 
        ' outputTextbox2
        ' 
        outputTextbox2.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        outputTextbox2.BackColor = Color.White
        outputTextbox2.Font = New Font("Consolas", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        outputTextbox2.Location = New Point(296, 12)
        outputTextbox2.Name = "outputTextbox2"
        outputTextbox2.ReadOnly = True
        outputTextbox2.Size = New Size(863, 501)
        outputTextbox2.TabIndex = 27
        outputTextbox2.Text = ""
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(156, 322)
        Button1.Name = "Button1"
        Button1.Size = New Size(123, 29)
        Button1.TabIndex = 29
        Button1.Text = "About..."
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AcceptButton = bttn_Check
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1171, 525)
        Controls.Add(Button1)
        Controls.Add(outputTextbox2)
        Controls.Add(Label17)
        Controls.Add(Label16)
        Controls.Add(Label15)
        Controls.Add(Label14)
        Controls.Add(Label13)
        Controls.Add(Label12)
        Controls.Add(Label11)
        Controls.Add(Label10)
        Controls.Add(bttn_Check)
        Controls.Add(txt_IR)
        Controls.Add(txt_LOI)
        Controls.Add(txt_MgO)
        Controls.Add(txt_Fe2O3)
        Controls.Add(txt_Al2O3)
        Controls.Add(txt_SiO2)
        Controls.Add(txt_SO3)
        Controls.Add(txt_CaO)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "Form1"
        Text = "ASTM C-150 Cement Composition Check"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents txt_CaO As TextBox
    Friend WithEvents txt_SO3 As TextBox
    Friend WithEvents txt_SiO2 As TextBox
    Friend WithEvents txt_Al2O3 As TextBox
    Friend WithEvents txt_Fe2O3 As TextBox
    Friend WithEvents txt_MgO As TextBox
    Friend WithEvents txt_LOI As TextBox
    Friend WithEvents txt_IR As TextBox
    Friend WithEvents bttn_Check As Button
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents outputTextbox2 As RichTextBox
    Friend WithEvents Button1 As Button
End Class
